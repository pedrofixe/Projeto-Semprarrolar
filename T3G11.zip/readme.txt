               _____   ___  ___ ___  ____   ____    ____  ____   ____    ___   _       ____  ____
              / ___/  /  _]|   |   ||    \ |    \  /    ||    \ |    \  /   \ | |     /    ||    \
             (   \_  /  [_ | _   _ ||  o  )|  D  )|  o  ||  D  )|  D  )|     || |    |  o  ||  D  )
              \__  ||    _]|  \_/  ||   _/ |    / |     ||    / |    / |  O  || |___ |     ||    /
              /  \ ||   [_ |   |   ||  |   |    \ |  _  ||    \ |    \ |     ||     ||  _  ||    \
              \    ||     ||   |   ||  |   |  .  \|  |  ||  .  \|  .  \|     ||     ||  |  ||  .  \
               \___||_____||___|___||__|   |__|\_||__|__||__|\_||__|\_| \___/ |_____||__|__||__|\_|

               

Trabalho desenvolvido por F�bio Oliveira : up201604796 e Pedro Franco : up201604828 no �mbito da cadeira de Programa��o.


�ndice:
	i. 	Objetivos Cumpridos
	ii. 	Limita��es Reconhecidas
	iii. 	Melhorias efetuadas
	iv. 	Notas

	
	i. Objetivos Cumpridos
	
Foram implementadas todas a funcionalidades pedidas pertinentes ao primeiro projeto. Nomeadamente:
	-Ler e guardar a informa��o de linhas e condutores armazenada em ficheiros;
	-Gerir os condutores: criar, alterar e remover um condutor;
	-Gerar e visualizar de modo formatado tabelas com hor�rios de uma paragem;
	-Visualizar o trabalho atribu�do a um condutor;
	-Visualizar a informa��o de um autocarro;
	-Visualizar a informa��o de uma linha, visualizando de modo formatado a tabela com o seu hor�rio;
	-Inquirir sobre quais as linhas que incluem determinada paragem;
	-Calcular e visualizar um percurso e tempo de viagem entre duas quaisquer paragens indicadas pelo
utilizador;
	-Listar todos os per�odos de autocarros sem condutor atribu�do.
	-Listar todos os per�odos de condutores sem o servi�o completo atribu�do (que n�o tenham atingido o
limite m�ximo semanal).
	-Efetuar interactivamente a atribui��o de servi�o a um condutor
	
	ii. Limita��es reconhecidas

	-At� este momento n�o s�o reconhecidas quaisquer funcionalidades pretendidas pelo enunciado, n�o implementadas.
	
	
	iii. Melhorias efetuadas
	
De modo a tornar o programa mais realista foram implementadas as seguintes melhorias:

	- Foi considerado que um mesmo autocarro pode ser usado por condutores diferentes em diferentes trajetos.
	- Foi implementado uma interface de visualiza��o hor�rios de trabalho/servi�os para condutores e autocarros.
	
	iv. Notas
	
Gostariamos ainda de destacar os seguintes pontos:
	- O programa corre nos sistemas operativos Windows/Mac/Linux sem diferen�a de funcionalidades ou formata��o de texto entre
	eles. � completamente cross-platform nesse �mbito. N�o � feita nenhuma chamada (direta) ao sistema operativo ao longo do programa.
	- Como n�o foi indicado no enunciado do Projeto as horas a que as linhas operam, foi declarado no c�digo 2 defines, SCHEDULE_START e SCHEDULE_END para esse mesmo efeito. 
	- O nome dos ficheiros de base de dados s�o pedidos ao utilizador.
	- De modo a tornar o c�digo mais leg�vel, alguma s�ntaxe introduzida pelo standard C++11 foi empregue, nomeadamente 
	range-bases for loops (aquando da itera��o de vetores).
	- O projeto � fortemente orientado a classes, sendo OOP o principal paradigma patente no nosso trabalho.
	- As seguintes bibliotecas da STL foram usadas (em nenhuma ordem particular):
	iostream, string, iomanip, vector, fstream, sstream, algorithm, cctype, set, map, cmath